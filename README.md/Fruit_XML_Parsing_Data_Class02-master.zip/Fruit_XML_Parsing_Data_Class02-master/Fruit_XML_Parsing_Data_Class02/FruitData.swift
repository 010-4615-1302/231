//
//  FruitData.swift
//  Fruit_XML_Parsing_Data_Class02
//
//  Created by D7702_09 on 2018. 10. 1..
//  Copyright © 2018년 jhi. All rights reserved.
//

import Foundation
class FruitData {
    var name = ""
    var color = ""
    var cost = ""
    
}


